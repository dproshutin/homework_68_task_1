import React from 'react';
import './App.css';
import Counter from "./Containers/Counter/Counter";

function App() {
  return (
    <Counter/>
  );
}

export default App;
